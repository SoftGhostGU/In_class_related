/* This file is derived from source code for the Nachos
   instructional operating system.  The Nachos copyright notice
   is reproduced in full below. */

/* Copyright (c) 1992-1996 The Regents of the University of California.
   All rights reserved.

   Permission to use, copy, modify, and distribute this software
   and its documentation for any purpose, without fee, and
   without written agreement is hereby granted, provided that the
   above copyright notice and the following two paragraphs appear
   in all copies of this software.

   IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO
   ANY PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR
   CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OF THIS SOFTWARE
   AND ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA
   HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY
   WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
   PURPOSE.  THE SOFTWARE PROVIDED HEREUNDER IS ON AN "AS IS"
   BASIS, AND THE UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO
   PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
   MODIFICATIONS.
*/

#include "threads/synch.h"
#include <stdio.h>
#include <string.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

static bool lock_priority_greater(const struct list_elem *lhs,const struct list_elem* rhs, void *aux UNUSED);
/* Initializes semaphore SEMA to VALUE.  A semaphore is a
   nonnegative integer along with two atomic operators for
   manipulating it:

   - down or "P": wait for the value to become positive, then
     decrement it.

   - up or "V": increment the value (and wake up one waiting
     thread, if any). */
void
sema_init (struct semaphore *sema, unsigned value) 
{
  ASSERT (sema != NULL);

  sema->value = value;
  list_init (&sema->waiters);
}

/* Down or "P" operation on a semaphore.  Waits for SEMA's value
   to become positive and then atomically decrements it.

   This function may sleep, so it must not be called within an
   interrupt handler.  This function may be called with
   interrupts disabled, but if it sleeps then the next scheduled
   thread will probably turn interrupts back on. */
void
sema_down (struct semaphore *sema) 
{
  enum intr_level old_level;

  ASSERT (sema != NULL);
  ASSERT (!intr_context ());

  old_level = intr_disable ();
  while (sema->value == 0) 
    {
      list_push_back (&sema->waiters, &thread_current ()->elem);
      thread_block ();
    }
  sema->value--;
  intr_set_level (old_level);
}

/* Down or "P" operation on a semaphore, but only if the
   semaphore is not already 0.  Returns true if the semaphore is
   decremented, false otherwise.

   This function may be called from an interrupt handler. */
bool
sema_try_down (struct semaphore *sema) 
{
  enum intr_level old_level;
  bool success;

  ASSERT (sema != NULL);

  old_level = intr_disable ();
  if (sema->value > 0) 
    {
      sema->value--;
      success = true; 
    }
  else
    success = false;
  intr_set_level (old_level);

  return success;
}
static bool
thread_priority_greater(const struct list_elem *lhs,const struct list_elem* rhs, void *aux UNUSED)
 {
  return list_entry(lhs, struct thread, elem)->priority> list_entry(rhs, struct thread, elem)->priority;
}
/* Up or "V" operation on a semaphore.  Increments SEMA's value
   and wakes up one thread of those waiting for SEMA, if any.

   This function may be called from an interrupt handler. */
void
sema_up (struct semaphore *sema) 
{
  enum intr_level old_level;

  ASSERT (sema != NULL);

  old_level = intr_disable ();
  //在将锁释放等情况用到信号量时候，从多个等待线程中唤醒优先级最大的
  if (!list_empty (&sema->waiters)) 
  {
    struct list_elem *_elem=list_min(&sema->waiters,thread_priority_greater,NULL);
    struct thread* _thread=list_entry(_elem,struct thread,elem);
    list_remove(_elem);
    thread_unblock(_thread);
  }
  sema->value++;
  intr_set_level (old_level);
  //在唤醒后可能需要进行重新调度所以主动让步
  if(intr_context()){
    intr_yield_on_return();
  }else{
  thread_yield();
  }
}

static void sema_test_helper (void *sema_);

/* Self-test for semaphores that makes control "ping-pong"
   between a pair of threads.  Insert calls to printf() to see
   what's going on. */
void
sema_self_test (void) 
{
  struct semaphore sema[2];
  int i;

  printf ("Testing semaphores...");
  sema_init (&sema[0], 0);
  sema_init (&sema[1], 0);
  thread_create ("sema-test", PRI_DEFAULT, sema_test_helper, &sema);
  for (i = 0; i < 10; i++) 
    {
      sema_up (&sema[0]);
      sema_down (&sema[1]);
    }
  printf ("done.\n");
}

/* Thread function used by sema_self_test(). */
static void
sema_test_helper (void *sema_) 
{
  struct semaphore *sema = sema_;
  int i;

  for (i = 0; i < 10; i++) 
    {
      sema_down (&sema[0]);
      sema_up (&sema[1]);
    }
}

/* Initializes LOCK.  A lock can be held by at most a single
   thread at any given time.  Our locks are not "recursive", that
   is, it is an error for the thread currently holding a lock to
   try to acquire that lock.

   A lock is a specialization of a semaphore with an initial
   value of 1.  The difference between a lock and such a
   semaphore is twofold.  First, a semaphore can have a value
   greater than 1, but a lock can only be owned by a single
   thread at a time.  Second, a semaphore does not have an owner,
   meaning that one thread can "down" the semaphore and then
   another one "up" it, but with a lock the same thread must both
   acquire and release it.  When these restrictions prove
   onerous, it's a good sign that a semaphore should be used,
   instead of a lock. */
void
lock_init (struct lock *lock)
{
  ASSERT (lock != NULL);
  lock->max_priority_in_query_threads=PRI_MIN;//初始化请求锁列表中最大优先级为0
  lock->holder = NULL;
  sema_init (&lock->semaphore, 1);
}

/* Acquires LOCK, sleeping until it becomes available if
   necessary.  The lock must not already be held by the current
   thread.

   This function may sleep, so it must not be called within an
   interrupt handler.  This function may be called with
   interrupts disabled, but interrupts will be turned back on if
   we need to sleep. */
void
lock_acquire (struct lock *lock)
{
  ASSERT (lock != NULL);
  ASSERT (!intr_context ());
  ASSERT (!lock_held_by_current_thread (lock));

  struct thread* current_thread=thread_current();
  //在获取锁之前要判断锁是否被其他线程持有
  if(lock->holder!=NULL&&!thread_mlfqs)
  {
    current_thread->await_lock=lock;
    //如果被其他线程所持有，那么比较当前线程和其他线程的优先级大小进行捐赠
    //首先更新锁的最大优先级
    if(current_thread->priority>lock->max_priority_in_query_threads){
      lock->max_priority_in_query_threads=current_thread->priority;
    }
    struct thread *lock_holder=lock->holder;
    //其次更新锁的持有者的优先级（即捐赠）
    if(current_thread->priority>lock_holder->priority){
      lock_holder->priority=current_thread->priority;
    }
    //在最大深度之前进行多级捐赠
    size_t depth=0;
    while(lock_holder->await_lock!=NULL&&depth<PRI_DEFAULT)
    {
      struct thread *lock_holder_next=lock_holder->await_lock->holder;
      //这一步放在if判断前很关键
      lock_holder->await_lock->max_priority_in_query_threads=lock_holder->priority;
      if(lock_holder_next->priority >lock_holder->priority)
      {
        break;
      }
      lock_holder_next->priority=lock_holder->priority;
      lock_holder=lock_holder_next;
      depth++;

    }
  }
  sema_down (&lock->semaphore);
  //在获取到锁之后，将锁有序插入线程的locks_possess_list中同时更新当前线程的等待锁
  lock->holder = current_thread;
  if(!thread_mlfqs){
      list_insert_ordered(&current_thread->locks_possess_list,&lock->elem, lock_priority_greater,NULL);
      current_thread->await_lock=NULL;
  }
}

static bool
lock_priority_greater(const struct list_elem *lhs,const struct list_elem* rhs, void *aux UNUSED) 
{
  return list_entry(lhs, struct lock, elem)->max_priority_in_query_threads> list_entry(rhs, struct lock, elem)->max_priority_in_query_threads;
}

/* Tries to acquires LOCK and returns true if successful or false
   on failure.  The lock must not already be held by the current
   thread.

   This function will not sleep, so it may be called within an
   interrupt handler. */
bool
lock_try_acquire (struct lock *lock)
{
  bool success;

  ASSERT (lock != NULL);
  ASSERT (!lock_held_by_current_thread (lock));

  success = sema_try_down (&lock->semaphore);
  if (success)
    lock->holder = thread_current ();
  return success;
}

/* Releases LOCK, which must be owned by the current thread.

   An interrupt handler cannot acquire a lock, so it does not
   make sense to try to release a lock within an interrupt
   handler. */
void
lock_release (struct lock *lock) 
{
  ASSERT (lock != NULL);
  ASSERT (lock_held_by_current_thread (lock));
  if(!thread_mlfqs){
  struct thread* current_thread=thread_current();
  list_remove(&lock->elem);
  //将锁释放后首先将优先级还原为原始优先级
  current_thread->priority=current_thread->init_priority;
  //其次如果还有别的锁，那么在别的锁的持有线程的最大优先级大于当前优先级时更新
  if(!list_empty(&current_thread->locks_possess_list))
  {
    struct lock* next_lock=list_entry(list_front(&current_thread->locks_possess_list),struct lock,elem);
    if(next_lock->max_priority_in_query_threads>current_thread->priority)
    {
      current_thread->priority=next_lock->max_priority_in_query_threads;
    }
  }
  }
  lock->holder = NULL;
  sema_up (&lock->semaphore);
}

/* Returns true if the current thread holds LOCK, false
   otherwise.  (Note that testing whether some other thread holds
   a lock would be racy.) */
bool
lock_held_by_current_thread (const struct lock *lock) 
{
  ASSERT (lock != NULL);

  return lock->holder == thread_current ();
}

/* One semaphore in a list. */
struct semaphore_elem 
  {
    struct list_elem elem;              /* List element. */
    struct semaphore semaphore;         /* This semaphore. */
  };

/* Initializes condition variable COND.  A condition variable
   allows one piece of code to signal a condition and cooperating
   code to receive the signal and act upon it. */
void
cond_init (struct condition *cond)
{
  ASSERT (cond != NULL);

  list_init (&cond->waiters);
}

/* Atomically releases LOCK and waits for COND to be signaled by
   some other piece of code.  After COND is signaled, LOCK is
   reacquired before returning.  LOCK must be held before calling
   this function.

   The monitor implemented by this function is "Mesa" style, not
   "Hoare" style, that is, sending and receiving a signal are not
   an atomic operation.  Thus, typically the caller must recheck
   the condition after the wait completes and, if necessary, wait
   again.

   A given condition variable is associated with only a single
   lock, but one lock may be associated with any number of
   condition variables.  That is, there is a one-to-many mapping
   from locks to condition variables.

   This function may sleep, so it must not be called within an
   interrupt handler.  This function may be called with
   interrupts disabled, but interrupts will be turned back on if
   we need to sleep. */
void
cond_wait (struct condition *cond, struct lock *lock) 
{
  struct semaphore_elem waiter;

  ASSERT (cond != NULL);
  ASSERT (lock != NULL);
  ASSERT (!intr_context ());
  ASSERT (lock_held_by_current_thread (lock));
  
  sema_init (&waiter.semaphore, 0);
  list_push_back (&cond->waiters, &waiter.elem);
  lock_release (lock);
  sema_down (&waiter.semaphore);
  lock_acquire (lock);
}
//根据cond的waiters中的元素来获取到到信号量指针来进行比较信号量等待队列中优先级的大小
static bool
sema_priority_greater(const struct list_elem *lhs,
                      const struct list_elem* rhs, void *aux UNUSED)
{
  struct semaphore *semal = &list_entry(lhs, struct semaphore_elem, elem)->semaphore;
  struct semaphore *semar = &list_entry(rhs, struct semaphore_elem, elem)->semaphore;
  return list_entry(list_min(&semal->waiters, thread_priority_greater, NULL), struct thread, elem)->priority
       > list_entry(list_min(&semar->waiters, thread_priority_greater, NULL), struct thread, elem)->priority;
  // return list_entry(list_front(&semal->waiters), struct thread, elem)->priority
  //      > list_entry(list_front(&semar->waiters), struct thread, elem)->priority;
}

/* If any threads are waiting on COND (protected by LOCK), then
   this function signals one of them to wake up from its wait.
   LOCK must be held before calling this function.

   An interrupt handler cannot acquire a lock, so it does not
   make sense to try to signal a condition variable within an
   interrupt handler. */
void
cond_signal (struct condition *cond, struct lock *lock UNUSED) 
{
  ASSERT (cond != NULL);
  ASSERT (lock != NULL);
  ASSERT (!intr_context ());
  ASSERT (lock_held_by_current_thread (lock));

  if (!list_empty (&cond->waiters)) 
  {
    //从cond的等待队列中取优先级最大的
    struct list_elem* _elem=list_min(&cond->waiters,sema_priority_greater,NULL);
    //在原先的做法中是采用list_pop_front的因此修改后需要手动移除队列中
    list_remove(_elem);
    struct semaphore* _semaphore=&list_entry(_elem,struct semaphore_elem,elem)->semaphore;
    sema_up(_semaphore);
  }
}

/* Wakes up all threads, if any, waiting on COND (protected by
   LOCK).  LOCK must be held before calling this function.

   An interrupt handler cannot acquire a lock, so it does not
   make sense to try to signal a condition variable within an
   interrupt handler. */
void
cond_broadcast (struct condition *cond, struct lock *lock) 
{
  ASSERT (cond != NULL);
  ASSERT (lock != NULL);

  while (!list_empty (&cond->waiters))
    cond_signal (cond, lock);
}
